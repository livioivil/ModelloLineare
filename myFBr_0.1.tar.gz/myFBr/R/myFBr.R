#' myFBr: it Reads and visualizes the infos of your FaceBook profile
#'
#' The myFBr package provides three categories of important functions:
#' foo, bar and baz.
#' 
#' @section myFBr functions:
#' The foo functions ...
#'
#' @docType package
#' @name myFBr
#' @import XML
NULL
#> NULL
