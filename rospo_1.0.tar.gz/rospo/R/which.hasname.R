which.hasname <-
function(X,name){
  which(names(X)==name)
}
