rowVars <-
function(X,...) apply(X,1,var,...)
