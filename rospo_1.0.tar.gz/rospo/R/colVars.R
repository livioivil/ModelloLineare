colVars <-
function(X,...) apply(X,2,var,...)
