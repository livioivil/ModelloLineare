
# rospo
R utilities by associazionerospo.org


* * *

## Set up

To **install** this github version type (in R):

    #if devtools is not installed yet: 
    # install.packages("devtools") 
    library(devtools)
    install_github("livioivil/rospo")
    library(rospo)


* * *